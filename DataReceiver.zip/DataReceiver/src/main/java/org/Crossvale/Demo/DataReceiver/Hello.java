package org.Crossvale.Demo.DataReceiver;

/**
 * An interface for implementing Hello services.
 */
public interface Hello {

    String hello();
	
}
